<div class="sidebar" data-color="purple" data-background-color="white" data-image="../assets/img/sidebar-1.jpg">
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | azure | green | orange | danger"

        Tip 2: you can also add an image using data-image tag
    -->
      <div class="logo"><a href="http://www.creative-tim.com" class="simple-text logo-normal">
          E-Shop
        </a></div>
      <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="nav-item <?php echo e(Request::is('dashboard') ? 'active':''); ?>  ">
            <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">
              <i class="material-icons">dashboard</i>
              <p>Dashboard</p>
            </a>
          </li>
          <li class="nav-item <?php echo e(Request::is('categories') ? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(url('/categories')); ?>">
              <i class="material-icons">library_books</i>
              <p>Category</p>
            </a>
          </li>
          <li class="nav-item <?php echo e(Request::is('products') ? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(url('/products')); ?>">
              <i class="material-icons">library_books</i>
              <p>Product</p>
            </a>
          </li>


          <li class="nav-item <?php echo e(Request::is('orders') ? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(url('/orders')); ?>">
              <i class="material-icons">library_books</i>
              <p>Orders</p>
            </a>
          </li>

          <li class="nav-item <?php echo e(Request::is('users') ? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(url('/users')); ?>">
              <i class="material-icons">person</i>
              <p>All Users</p>
            </a>
          </li>


          <li class="nav-item <?php echo e(Request::is('setting') ? 'active':''); ?>">
            <a class="nav-link" href="<?php echo e(url('/setting')); ?>">
              <i class="material-icons">library_books</i>
              <p>Setting</p>
            </a>
          </li>

        </ul>
      </div>
    </div><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom2\resources\views/layouts/inc/sidebar.blade.php ENDPATH**/ ?>