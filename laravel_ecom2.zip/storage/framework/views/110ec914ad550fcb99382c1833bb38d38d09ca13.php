                                     <!-- showing main component  -->
             
<?php $__env->startSection('content'); ?>
<div class="card">
      <div class="card-header bg-primary text-white">
                  <h4>Registered Users</h4>
      </div>
      <div class="card-body">
             <table class="table">
                   <thead>
                         <tr>
                               <th>Id</th>
                               <th>Name</th>
                               <th>Email</th>
                               <th>Phone</th>
                               <th>Action</th>
                         </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                              <td><?php echo e($item->id); ?></td>              
                              <td><?php echo e($item->name); ?></td> 
                              <td><?php echo e($item->email); ?></td>             
                              <td><?php echo e($item->phone); ?></td>             
                              <td>
                                    <a href="<?php echo e(url('view-user/'.$item->id)); ?>" class="btn btn-primary">View</a>
                              </td>              
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
            </table>                                
      </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom2\resources\views/admin/users/users.blade.php ENDPATH**/ ?>