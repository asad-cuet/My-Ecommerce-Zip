                                     <!-- showing main component  -->
             
<?php $__env->startSection('content'); ?>
<style>
      nav svg {
               height:20px;
              }
</style>
<div class="card">
      <div class="card-body">
             <div class="col-md-12">    
                  <a href="<?php echo e(url('products/insert_form')); ?>" class="btn btn-primary">Add Product</a>

                  <div class="float-right">
                  <form class="navbar-form" method="POST" action="<?php echo e(url('/admin/search/product')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="input-group no-border">
                          <input type="text" name="product_name" id="auto_complete" class="form-control" placeholder="Search Product">
                          <button type="submit" class="btn btn-white btn-round btn-just-icon">
                            <i class="material-icons">search</i>
                            <div class="ripple-container"></div>
                          </button>
                        </div>
                  </form>
                  </div>    

             </div> 



             <table class="table">
                   <thead>
                         <tr>
                               <th>Id</th>
                               <th>Name</th>
                               <th>Category</th>
                               <th>Image</th>
                               <th>Original Price</th>
                               <th>Selling Price</th>
                               <th>Quantity</th>
                               <th>Tax</th>
                               <th>Status</th>
                               <th>Trending</th>
                               <th>Action</th>
                         </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                              <td><?php echo e($item->id); ?></td>              
                              <td><?php echo e($item->name); ?></td> 
                              <td><?php echo e($item->category->name); ?></td> 
                              <td><img src="<?php echo e(asset('assets/uploads/product/'.$item->image)); ?>" style="max-width:70px;"></td>                           
                              <td><?php echo e($item->original_price); ?></td>              
                              <td><?php echo e($item->selling_price); ?></td>              
                              <td><?php echo e($item->qty); ?></td>              
                              <td><?php echo e($item->tax); ?></td>              
                              <td><?php echo e($item->status); ?></td>              
                              <td><?php echo e($item->trending); ?></td>              
                              <td>
                                    <a href="<?php echo e(url('products/edit/'.$item->id)); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(url('products/delete/'.$item->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                              </td>              
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
            </table>  
            <?php echo e($product->links()); ?>                              
      </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/admin/product/index.blade.php ENDPATH**/ ?>