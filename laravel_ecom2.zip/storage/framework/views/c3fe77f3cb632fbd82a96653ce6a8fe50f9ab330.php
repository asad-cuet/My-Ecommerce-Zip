                                     <!-- showing main component  -->
   
<?php $__env->startSection('title'); ?>
<?php echo e(App\Models\Setting::first()->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta'); ?>
<meta name="title" content="<?php echo e(App\Models\Setting::first()->meta_title); ?>">
<meta name="description" content="<?php echo e(App\Models\Setting::first()->meta_descript); ?>">
<meta name="keywords" content="<?php echo e(App\Models\Setting::first()->meta_keywords); ?>">    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.front_inc.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      

<div class="py-5">
      <div class="container">
            <div class="row">
                  <h4>Featured Products</h4>
                  <div class="owl-carousel featured-carousel owl-theme">
                        <?php $__currentLoopData = $feteaured_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('category/'.$item->category->slug.'/'.$item->slug)); ?>">
                              <div class="item">
                                    <div class="card">
                                          <img src="<?php echo e(asset('assets/uploads/product/'.$item->image)); ?>" alt="Product Image">
                                          <div class="card-body">
                                                <h5><?php echo e($item->name); ?></h5>
                                                <span class="float-start"><?php echo e($item->selling_price); ?></span>
                                                <span class="float-end"><s><?php echo e($item->original_price); ?></s></span>
                                          </div>
                                    </div>
                              </div>
                        </a>      
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
            </div>
      </div>
</div>


<div class="py-5">
      <div class="container">
            <div class="row">
                  <h4>Trending Category</h4>
                  <div class="owl-carousel category-carousel owl-theme">
                        <?php $__currentLoopData = $trending_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <a href="<?php echo e(url('category/'.$item->slug)); ?>" >
                              <div class="item">
                                    <div class="card">
                                          <img src="<?php echo e(asset('assets/uploads/category/'.$item->image)); ?>" alt="Product Image">
                                          <div class="card-body">
                                                <h5><?php echo e($item->name); ?></h5>
                                          </div>
                                    </div>
                              </div>
                              </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
            </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php if(Auth::user()): ?>
      <?php if(Auth::user()->email_verified_at==NULL): ?>
      <script>
      swal("Verify Your Email Address.Check Your Mail");
      </script>    
      <?php endif; ?>   
<?php endif; ?>   


<script>
      $('.featured-carousel').owlCarousel({
            loop:true,
            margin:10,
            autoplay:true,
            autoplayTimeout:1500,
            autoplayHoverPause:true,
            dots:false,
            responsiveClass:true,
            responsive:{
            0:{
                  items:2,
                  nav:true
            },
            600:{
                  items:4,
                  nav:false
            },
            1000:{
                  items:7,
                  nav:true,
                  loop:true
            }
            }
      })
      $('.category-carousel').owlCarousel({
            loop:true,
            margin:0,
            autoplay:true,
            autoplayTimeout:1500,
            autoplayHoverPause:true,
            dots:false,
            responsiveClass:true,
            responsive:{
            0:{
                  items:2,
                  nav:true
            },
            600:{
                  items:4,
                  nav:false
            },
            1000:{
                  items:7,
                  nav:true,
                  loop:true
            }
            }
      })

 </script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom2\resources\views/frontend/dashboard.blade.php ENDPATH**/ ?>