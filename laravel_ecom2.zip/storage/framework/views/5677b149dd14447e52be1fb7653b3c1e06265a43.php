                                     <!-- showing main component  -->
             
<?php $__env->startSection('content'); ?>
<div class="card">
      <div class="card-body">
             <div class="col-md-12">    
                  <a href="<?php echo e(url('categories/insert_form')); ?>" class="btn btn-primary">Add Category</a>
             </div> 



             <table class="table">
                   <thead>
                         <tr>
                               <th>Id</th>
                               <th>Name</th>
                               <th>Image</th>
                               <th>Action</th>
                         </tr>
                  </thead>
                  <tbody>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                              <td><?php echo e($item->id); ?></td>              
                              <td><?php echo e($item->name); ?></td>              
                              <td><img src="<?php echo e(asset('assets/uploads/category/'.$item->image)); ?>" style="max-width:70px;"></td>              
                              <td>
                                    <a href="#" class="btn btn-secondary">View</a>
                                    <a href="<?php echo e(url('categories/edit/'.$item->id)); ?>" class="btn btn-primary">Edit</a>
                                    <a href="<?php echo e(url('categories/delete/'.$item->id)); ?>" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                              </td>              
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
            </table>                                
      </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/admin/category/index.blade.php ENDPATH**/ ?>