

<?php $__env->startSection('title','Write a Review'); ?>
    
<?php $__env->startSection('content'); ?>
    
<div class="container py-5">
      <div class="row">
            <div class="col-md-12">
                  <div class="card">
                        <div class="card-body">
                                   <h5>You are writing a review for <?php echo e($review->product->name); ?></h5>
                                   <form action="<?php echo e(url('/update-review')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                         <input type="hidden" name="review_id" value="<?php echo e($review->id); ?>">
                                         <textarea name="user_review" cols="30" rows="10" class="form-control" placeholder="Write a review"><?php echo e($review->user_review); ?></textarea>
                                         <button type="submit" class="btn btn-primary mt-3">Submit Review</button>

                                   </form>
                        </div>
                  </div>
            </div>
      </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/frontend/review/edit.blade.php ENDPATH**/ ?>