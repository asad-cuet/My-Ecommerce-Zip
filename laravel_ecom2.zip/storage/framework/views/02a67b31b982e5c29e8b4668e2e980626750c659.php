                                     <!-- showing main component  -->
   
<?php $__env->startSection('title'); ?>
Wishlist
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="py-3 mb-4 shadow-sm bg-warning border-top">
      <div class="container">
            <h6 class="mb-0">Wishlist</h6>      
      </div>       
</div>  



<div class="container my-5">
      <div class="card shadow wishlistitems">
            <?php if($wishlist->count()>0): ?>
            <div class="card-body">
                 
                  <?php $__currentLoopData = $wishlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row product_data">
     
                        <div class="col-md-2 my-auto">
                              <img src="<?php echo e(asset('assets/uploads/product/'.$item->product->image)); ?>" height="70px" width="70px" alt="Image">
                        </div>
                        <div class="col-md-2 my-auto">
                            <h6><?php echo e($item->product->name); ?></h6>
                        </div>
                        <div class="col-md-2 my-auto">
                            <h6>Rs <?php echo e($item->product->selling_price); ?></h6>
                        </div>
                        <div class="col-md-2 my-auto">
                              <input type="hidden" value="<?php echo e($item->product->id); ?>" class="prod_id">
                              <input type="hidden" value="<?php echo e($item->id); ?>" class="wish_id">
                        <?php if($item->product->qty>0): ?>
                              <label class="badge bg-success">In stock</label>
                              <?php else: ?>       
                              <label class="badge bg-danger">Out of stock</label> 
                        <?php endif; ?>
                        </div>
                        <div class="col-md-2 my-auto">
                              <input type="hidden" name="quantity" value="1" class="form-control qty-input text-center" />
                              <button class="btn btn-success addToCartBtn"><i class="fa fa-shopping-cart"></i>Add to Cart</button>
                        </div>
                        <div class="col-md-2 my-auto">
                              <button class="btn btn-danger delete-wishlist-item"><i class="fa fa-trash"></i>Remove</button>
                        </div>
                         
                  </div>
                 
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php else: ?>
            <div class="card-body text-center">
                  <h2>Your <i class="fa fa-shopping-cart"> Wishlist is empty</i></h2>
                  <a href="<?php echo e(url('/category')); ?>" class="btn btn-outline-primary float-end">Continue Shoppinh</a>
            </div>
            <?php endif; ?>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom2\resources\views/frontend/wishlist/wishlist.blade.php ENDPATH**/ ?>