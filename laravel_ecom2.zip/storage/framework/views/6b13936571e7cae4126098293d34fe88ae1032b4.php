[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>