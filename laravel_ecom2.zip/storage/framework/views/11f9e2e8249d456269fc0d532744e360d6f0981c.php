                                     <!-- showing main component  -->
             
<?php $__env->startSection('content'); ?>
<div class="card">
      <div class="card-body text-dark">

      <form method="POST" action="<?php echo e(url('products/insert')); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> 
            <div class="row">
            <div class="col-md-12 mb-3">
                  <select class="form-select form-control border" name="cate_id">
                        <option selected>Select a category</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
            </div>      
                      
            <div class="col-md-6 mb-3">
                  <label for="">Name</label>
                  <input type="text" id="name" class="form-control" name="name">
            </div>            
            <div class="col-md-6 mb-3">
                  <label for="">Slug</label>
                  <input type="text" id="slug" class="form-control" name="slug">
            </div>            

            <script>   
                  $('#name').keyup(function()   //click
                  {
                  var name=$('#name').val();
                  name=name.replace(/\s+/g, '-');
                  $('#slug').val(name);
                  });
            </script>


            <div class="col-md-12 mb-3">
                  <label for="">Small Description</label>
                  <textarea id="myMce" class="form-control" name="small_description"></textarea>
            </div> 
            <div class="col-md-12 mb-3">
                  <label for="">Description</label>
                  <textarea id="myMce" class="form-control" name="description"></textarea>
            </div> 
            
            <div class="col-md-6 mb-3">
                  <label for="">Original Price</label>
                  <input type="number" name="original_price" class="form-control">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Selling Price</label>
                  <input type="number" name="selling_price" class="form-control">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Quantity</label>
                  <input type="number" name="qty" class="form-control">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Tax</label>
                  <input type="number" name="tax" class="form-control">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Active</label>  
                  <input checked type="checkbox" name="status">
            </div>  
            <div class="col-md-6 mb-3">
                  <label for="">Trending</label>
                  <input type="checkbox" name="trending">
            </div>  

            <div class="col-md-12 mb-3">
                  <label for="">Meta Title</label>
                  <input type="text" class="form-control" name="meta_title">
            </div>  

            <div class="col-md-12 mb-3">
                  <label for="">Meta Keywords</label>
                  <input type="text" class="form-control" name="meta_keywords">
            </div>  

     
            <div class="col-md-12 mb-3">
                  <label for="">Meta Description</label>
                  <textarea rows="3" class="form-control" name="meta_descript"></textarea>
            </div>
            <div class="col-md-12">
                  <input type="file" name="image" class="form-control">
            </div>

      <div class="col-md-12">    
           <button type="submit" class="btn btn-primary">Submit</button>
      </div> 

        </div>
      </form>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/admin/product/add.blade.php ENDPATH**/ ?>