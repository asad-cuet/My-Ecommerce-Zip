                                     <!-- showing main component  -->
             
<?php $__env->startSection('content'); ?>
    <div class="card">
          <div class="card-body">
                <h1>Dashboard</h1>
          </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>