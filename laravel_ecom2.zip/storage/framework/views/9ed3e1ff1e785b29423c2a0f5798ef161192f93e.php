                                     <!-- showing main component  -->
   
<?php $__env->startSection('title'); ?>
Search List
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="py-3 mb-4 shadow-sm bg-warning border-top">
      <div class="container">
            <h6 class="mb-0">Search Result</h6>      
      </div>       
</div>   

<div class="py-5">
      <div class="container">
            <div class="row">
                  
                 
                        <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <div class="col-md-3 mb-3">
                                    <div class="card">
                                    <a href="<?php echo e(url('category/'.$item->category->slug.'/'.$item->slug)); ?>">
                                    
                                          <img src="<?php echo e(asset('assets/uploads/product/'.$item->image)); ?>" alt="Product Image" class="w-100">
                                          <div class="card-body">
                                                <h5><?php echo e($item->name); ?></h5>
                                                <span class="float-start"><?php echo e($item->selling_price); ?></span>
                                                <span class="float-end"><s><?php echo e($item->original_price); ?></s></span>
                                          </div>
                                    
                                    </a>   
                                    </div>   

                              </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            </div>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom2\resources\views/frontend/search.blade.php ENDPATH**/ ?>