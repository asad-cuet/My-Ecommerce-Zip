                                     <!-- showing main component  -->
   
<?php $__env->startSection('title'); ?>
My Cart
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="py-3 mb-4 shadow-sm bg-warning border-top">
      <div class="container">
            <h6 class="mb-0">Your Shopping Cart</h6>      
      </div>       
</div>  



<div class="container my-5">
      <div class="card shadow cartitems">  <!-- cartitem for div reload -->
            <?php if($product->count()>0): ?>
            <div class="card-body">
                  <?php $total=0; ?>
                  <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="row product_data">
     
                        <div class="col-md-2 my-auto">
                              <img src="<?php echo e(asset('assets/uploads/product/'.$item->product->image)); ?>" height="70px" width="70px" alt="Image">
                        </div>
                        <div class="col-md-3 my-auto">
                            <h6><?php echo e($item->product->name); ?></h6>
                        </div>
                        <div class="col-md-2 my-auto">
                            <h6>Rs <?php echo e($item->product->selling_price); ?></h6>
                        </div>
                        <div class="col-md-3 my-auto">
                              <input type="hidden" value="<?php echo e($item->id); ?>" class="cart_id">
                              <?php if($item->product->qty >= $item->prod_qty): ?>
                              <label for="quantity">Quantity</label>
                              <div class="input-group text-center mb-3" style="width:130px;">
                                     <button class="input-group-text changeQuantity decrement-btn">-</button>
                                     <input type="text" name="quantity" value="<?php echo e($item->prod_qty); ?>" class="form-control qty-input text-center" />
                                     <button class="input-group-text changeQuantity increment-btn">+</button>      
                              </div>  
                              <?php $total+=($item->product->selling_price)*($item->prod_qty); ?>
                              <?php else: ?>
                                  <h6>Out of Stock</h6>                                  
                              <?php endif; ?>
                        </div>
                        <div class="col-md-2 my-auto">
                              <button class="btn btn-danger delete-cart-item"><i class="fa fa-trash"></i>Remove</button>
                        </div>
                         
                  </div>
                 
                  
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="card-footer">
                  <h6>Total Price : Rs <span class="total"><?php echo e($total); ?></span></h6>
                  <a href="<?php echo e(url('/checkout')); ?>" class="btn btn-outline-success float-end">Proceed to Checkout</a>
            </div>
            <?php else: ?>
            <div class="card-body text-center">
                  <h2>Your <i class="fa fa-shopping-cart"> Cart is empty</i></h2>
                  <a href="<?php echo e(url('/category')); ?>" class="btn btn-outline-primary float-end">Continue Shoppinh</a>
            </div>
            <?php endif; ?>
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Laravel 8\laravel_ecom2\resources\views/frontend/cart.blade.php ENDPATH**/ ?>