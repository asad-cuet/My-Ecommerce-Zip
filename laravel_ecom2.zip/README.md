This is a E-commerce website using Laravel 8

Used Language:
1.Html
2.Css, Bootstrap
3.Javascript
4.Jquery
5.Ajax
6.Laravel 8


How to run:

1.Clone it & run composer npm command

2.After ready of clone,create database

3.edit database name and set email in .env file.

4.Don't migrate

5.Import Tables, provided in repository

6.Done

Path:

Login: http://localhost:8000/login

Default Admin Email: asadul7733@gmail.com [change it from phpmyadmin]
Password: 12345678

Default User Email: user@gmail.com
Password: 12345678
	
Admin Panel: http://localhost:8000/dashboard



For setting logo,website name: http://localhost:8000/setting