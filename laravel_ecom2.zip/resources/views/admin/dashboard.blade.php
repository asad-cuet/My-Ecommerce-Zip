@extends('layouts.admin')                                     <!-- showing main component  -->
             
@section('content')
    <div class="card">
          <div class="card-body">
                <h1>Dashboard</h1>
          </div>
    </div>
@endsection